# E-commerce Secure Repository

Repository mẫu phục vụ việc chia sẻ mã nguồn dự án thương mại điện tử trên GitHub Public.

## Cấu trúc
- `.env.example`: mẫu biến môi trường cho Dev, Test, Production.
- `.gitignore`: loại trừ tệp bí mật và tệp sinh ra trong quá trình chạy.
- `.gitleaks.toml`: cấu hình cơ bản cho công cụ Gitleaks.
- `scripts/pre-push-checklist.md`: checklist trước khi push.
- `SECURITY.md`: hướng dẫn báo cáo vấn đề bảo mật.
- `RISK-REPORT.md`: đánh giá rủi ro khi thiếu `.gitignore`.

## Kiểm tra trước khi push
```bash
git status
git diff --cached
git grep -n -I -E "API_KEY|SECRET|PASSWORD|TOKEN"
gitleaks detect --source . --verbose
```

Không đưa thông tin đăng nhập thật vào repository. Nếu phát hiện secret đã bị commit hoặc công khai, hãy thu hồi/đổi secret ngay; xóa tệp ở commit mới không làm secret biến mất khỏi lịch sử Git.
