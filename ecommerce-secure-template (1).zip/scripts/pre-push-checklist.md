# Pre-push Security Checklist

Trước mỗi lần `git push`, người thực hiện cần kiểm tra:

- [ ] Không hardcode API Key, access token, mật khẩu, private key trong source code.
- [ ] Không stage hoặc commit `.env`, tệp credentials, chứng thư hay private key.
- [ ] `.gitignore` đã loại trừ các tệp bí mật; vẫn cho phép commit `.env.example`.
- [ ] `.env.example` chỉ chứa tên biến và placeholder, không chứa secret thật.
- [ ] Đã xem các thay đổi sẽ commit:
  ```bash
  git status
  git diff --cached
  ```
- [ ] Quét chuỗi nghi vấn trong mã nguồn:
  ```bash
  git grep -n -I -E "API_KEY|SECRET|PASSWORD|TOKEN"
  ```
- [ ] Quét secret bằng Gitleaks:
  ```bash
  gitleaks detect --source . --verbose
  ```
- [ ] Thành viên repository đã bật 2FA theo chính sách của tổ chức.

Nếu phát hiện secret đã bị đẩy lên remote: thu hồi/đổi secret ngay, kiểm tra lịch sử Git và thông báo người phụ trách bảo mật. Không chỉ xóa secret khỏi file ở commit mới.
