# Security Policy

## Báo cáo lỗ hổng
Không đăng API key, mật khẩu, token hoặc chi tiết khai thác lên issue công khai.
Hãy liên hệ riêng với người quản trị dự án qua kênh bảo mật do team thống nhất.

## Khi secret bị lộ
1. Thu hồi hoặc xoay vòng secret ngay tại nhà cung cấp.
2. Kiểm tra log truy cập và phạm vi ảnh hưởng.
3. Xóa secret khỏi mã nguồn và xử lý lịch sử Git khi cần.
4. Không xem việc xóa ở commit mới là đủ; secret cũ có thể còn trong lịch sử.
