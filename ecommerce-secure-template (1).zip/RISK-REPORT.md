# Báo cáo đánh giá rủi ro khi thiếu `.gitignore`

## 1. Mục đích
Đánh giá nguy cơ khi dự án thương mại điện tử được đẩy lên GitHub Public mà không có `.gitignore` phù hợp.

## 2. Các rủi ro chính

| Tệp/dữ liệu bị đẩy lên | Rủi ro | Mức độ |
|---|---|---|
| `.env` chứa API Key/token | Người khác sử dụng trái phép dịch vụ hoặc API | Rất cao |
| Mật khẩu kết nối cơ sở dữ liệu | Truy cập trái phép, rò rỉ dữ liệu khách hàng | Rất cao |
| Private key/chứng thư | Giả mạo hệ thống hoặc truy cập tài nguyên | Rất cao |
| Log chứa thông tin người dùng | Lộ dữ liệu cá nhân hoặc thông tin phiên | Cao |
| `node_modules`, `dist`, file tạm | Repository phình to, khó quản lý và review | Trung bình |

## 3. Biện pháp phòng tránh
- Tạo `.gitignore` trước khi commit, loại trừ `.env`, credentials, private key, log và thư mục build.
- Giữ lại `.env.example` nhưng chỉ dùng placeholder an toàn.
- Chạy Gitleaks trước khi push và kiểm tra nội dung staged.
- Bật 2FA cho tất cả thành viên; giới hạn quyền truy cập theo vai trò.
- Nếu secret đã bị lộ, thu hồi/đổi secret ngay và rà soát lịch sử Git.

## 4. Lưu ý
`.gitignore` chỉ ngăn Git theo dõi các tệp chưa được track. Nó không tự xóa tệp đã commit trước đó hoặc xóa secret khỏi lịch sử Git.
